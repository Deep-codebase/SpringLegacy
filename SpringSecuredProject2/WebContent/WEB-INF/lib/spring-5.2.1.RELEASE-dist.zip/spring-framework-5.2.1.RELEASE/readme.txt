Spring Framework version 5.2.1.RELEASE
=====================================================================================

To find out what has changed since earlier releases, see the release notes at
https://github.com/spring-projects/spring-framework/releases.

Please consult the documentation located within the 'docs/spring-framework-reference'
directory of this release and also visit the official Spring Framework home at
https://spring.io/projects/spring-framework.

There you will find links to the issue tracker and other resources.

See https://github.com/spring-projects/spring-framework#readme for additional
information including instructions on building from source.
